import 'package:flutter/material.dart';

const Color warnaHijauUtama = Color(0xff8BC34A);
const Color warnaHijauKedua = Color(0xffBEF67A);
const Color warnaHijauKetiga = Color(0xffF2FFAB); // background textfield
const Color warnaAbuIcon = Color(0xff565050);
const Color warnaAbuUtama = Color(0xff808080);
const Color warnaAbuKedua = Color(0xffC4C4C4);
const Color warnaAbuKetiga = Color(0xffF3F3F3); // total harga
const Color warnaPutih = Color(0xffFFFFFF);
const Color warnaHitam = Color(0xff000000);
const Color warnaHarga = Color(0xffFF0000);

// bold     = w700
// semibold = w600
// medium   = w500
// light    = w300s

TextStyle fs20medium = TextStyle(fontSize: 20.0, fontWeight: FontWeight.w500);
TextStyle fs12bold = TextStyle(fontSize: 12.0, fontWeight: FontWeight.w700);
TextStyle fs12semibold = TextStyle(fontSize: 12.0, fontWeight: FontWeight.w600);
TextStyle fs12medium = TextStyle(fontSize: 12.0, fontWeight: FontWeight.w500);
TextStyle fs15semibold = TextStyle(fontSize: 15.0, fontWeight: FontWeight.w600);
TextStyle fs16semibold = TextStyle(fontSize: 16.0, fontWeight: FontWeight.w600);
TextStyle fs14semibold = TextStyle(fontSize: 14.0, fontWeight: FontWeight.w600);
TextStyle fs10semibold = TextStyle(fontSize: 10.0, fontWeight: FontWeight.w600);
TextStyle fs12regulercoklat =
    TextStyle(fontSize: 12.0, color: Color(0xff696969));
TextStyle fs9semibold = TextStyle(fontSize: 9.0, fontWeight: FontWeight.w600);
TextStyle fs12semiboldputih = TextStyle(
    fontSize: 12.0, fontWeight: FontWeight.w600, color: Color(0xffFFFFFF));
TextStyle fs10medium = TextStyle(fontSize: 10.0, fontWeight: FontWeight.w500);
TextStyle fs9medium = TextStyle(fontSize: 9.0, fontWeight: FontWeight.w500);
TextStyle fs6light = TextStyle(fontSize: 6.0, fontWeight: FontWeight.w300);
TextStyle fs10light = TextStyle(fontSize: 10.0, fontWeight: FontWeight.w300);
TextStyle fs12light = TextStyle(fontSize: 12.0, fontWeight: FontWeight.w300);
TextStyle fs9light = TextStyle(fontSize: 9.0, fontWeight: FontWeight.w300);
TextStyle fs8light = TextStyle(fontSize: 8.0, fontWeight: FontWeight.w300);
