import 'dart:convert';
import 'package:apotek/home/detail_produk.dart';
import 'package:apotek/home/widgets/appbar_widget.dart';
import 'package:apotek/theme.dart';
import 'package:flutter/material.dart';
import 'widgets/kategori_produk_widget.dart';
import 'widgets/layanan_unggulan_widget.dart';
import 'package:http/http.dart' as http;

import 'widgets/produk_card_widget.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    Future<List> getObat() async {
      final listDummy = [];
      final response = await http
          .get("https://asy-syifa.web.id/apotekmobile/models/obat/getObat.php");
      listDummy.add(json.decode(response.body));
      return json.decode(response.body);
    }

    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(200),
        child: AppbarWidget(),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(12.5),
                    child: Text('Kategori Produk', style: fs14semibold),
                  ),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(width: 12.5),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/demam.png',
                          kategori: 'Demam\n& Nyeri',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/pernapasan.png',
                          kategori: 'Saluran\nPernapasan',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/pencernaan.png',
                          kategori: 'Saluran\nPencernaan',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/infeksi.png',
                          kategori: 'Anti Infeksi\n& Kanker',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/metabolisme.png',
                          kategori: 'Metabolisme\n',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/ots.png',
                          kategori: 'Otot, Tulang,\ndan Sendi',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/kemih.png',
                          kategori: 'Saluran Kemih\n& Prostat',
                        ),
                        SizedBox(width: 25),
                        KategoriProdukWidget(
                          imageAsset: 'assets/images/vitamin.png',
                          kategori: 'Vitamin &\nSuplemen',
                        ),
                        SizedBox(width: 12.5),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                ],
              ),
            ),
            Container(
              color: warnaHijauKetiga,
              width: width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 12.5, top: 13),
                    child: Text(
                      'Layanan Unggulan',
                      style: fs14semibold,
                    ),
                  ),
                  SizedBox(height: 10.5),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        SizedBox(width: 12),
                        LayananUnggulanWidget(
                            imageAsset: 'assets/images/layanan_rapid.jpg'),
                        SizedBox(width: 12),
                        LayananUnggulanWidget(
                            imageAsset: 'assets/images/layanan_swab.jpg'),
                        SizedBox(width: 12),
                        LayananUnggulanWidget(
                            imageAsset: 'assets/images/layanan_antar.jpeg'),
                        SizedBox(width: 12),
                        LayananUnggulanWidget(
                            imageAsset: 'assets/images/layanan_konsultasi.png'),
                        SizedBox(width: 12),
                      ],
                    ),
                  ),
                  SizedBox(height: 20)
                ],
              ),
            ),
            Container(
              width: width,
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 12, left: 12, bottom: 12),
                      child: Text(
                        'Rekomendasi Produk',
                        style: fs14semibold,
                        textAlign: TextAlign.left,
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: FutureBuilder(
                          future: getObat(),
                          builder: (context, snapshot) {
                            if (snapshot.hasError) print(snapshot.error);
                            return GridView.builder(
                              shrinkWrap: true,
                              physics: ScrollPhysics(),
                              itemCount: (snapshot.hasData)
                                  ? ProdukCardWidget(produkList: snapshot.data)
                                      .produkList
                                      .length
                                  : 10,
                              gridDelegate:
                                  SliverGridDelegateWithFixedCrossAxisCount(
                                childAspectRatio: 127 / 200, // width/height
                                mainAxisSpacing: 12,
                                crossAxisSpacing: 12,
                                crossAxisCount: 2,
                              ),
                              itemBuilder: (context, i) {
                                return (snapshot.hasData)
                                    ? GestureDetector(
                                        child: ProdukCardWidget(
                                          index: i,
                                          produkList: snapshot.data,
                                        ),
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) {
                                                return DetailProduk(
                                                  index: i,
                                                  produkData: snapshot.data,
                                                );
                                              },
                                            ),
                                          );
                                        },
                                      )
                                    : new Card(
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(15)),
                                        child: Container(
                                          padding: const EdgeInsets.all(11),
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(30),
                                              color: Colors.white),
                                          child: Center(
                                            child: CircularProgressIndicator(
                                                color: Colors.green.shade800),
                                          ),
                                        ),
                                      );
                              },
                            );
                          }),
                    ),
                    SizedBox(height: 30)
                  ]),
            ),
          ],
        ),
      ),
    );
  }
}
