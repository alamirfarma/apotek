import 'package:flutter/material.dart';

class SingleLineWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Container(
      width: width - 30,
      height: 2,
      color: Color(0xffC4C4C4),
    );
  }
}
