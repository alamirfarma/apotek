import 'package:flutter/material.dart';
import '../../theme.dart';

class KategoriProdukWidget extends StatelessWidget {
  final String imageAsset;
  final String kategori;

  KategoriProdukWidget({this.imageAsset, this.kategori});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Image(
          image: AssetImage(this.imageAsset),
          width: 50,
          height: 50,
          fit: BoxFit.cover,
        ),
        SizedBox(height: 5),
        Container(
          child: Text(
            '${this.kategori}',
            style: fs12medium,
            textAlign: TextAlign.center,
          ),
        )
      ],
    );
  }
}
