import 'package:flutter/material.dart';

import '../../theme.dart';

class DetailProdukItemWidget extends StatelessWidget {
  DetailProdukItemWidget({this.desc, this.title});

  final String title;
  final String desc;

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: width / 2.66,
          child: Text(title, style: fs12light),
        ),
        Container(
          width: width / 1.89,
          child: Text(desc, style: fs12light),
        ),
      ],
    );
  }
}
