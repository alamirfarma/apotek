import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../theme.dart';

class ProdukCardWidget extends StatelessWidget {
  final List produkList;
  final int index;

  ProdukCardWidget({this.produkList, this.index});

  @override
  Widget build(BuildContext context) {
    String gambar = produkList[index]['gambar'];
    String nama = produkList[index]['nama'];
    int harga = int.parse(produkList[index]['harga_jual']);

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Container(
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30), color: Colors.white),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.network(
              "https://asy-syifa.web.id/apotekmobile/produk/$gambar",
              width: 140,
              height: 130,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 18),
            Text(
              nama,
              style: fs12light,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              maxLines: 2,
            ),
            SizedBox(height: 16),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  NumberFormat.currency(
                          locale: 'id', decimalDigits: 0, symbol: 'Rp ')
                      .format(harga),
                  style: fs12semibold.copyWith(color: Colors.orange[900]),
                  textAlign: TextAlign.left,
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
