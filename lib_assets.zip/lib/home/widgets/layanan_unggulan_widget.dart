import 'package:flutter/material.dart';

class LayananUnggulanWidget extends StatelessWidget {
  final String imageAsset;

  LayananUnggulanWidget({this.imageAsset});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 245,
      height: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        image: DecorationImage(
            image: AssetImage(this.imageAsset), fit: BoxFit.cover),
      ),
    );
  }
}
