import 'package:flutter/material.dart';

import '../../theme.dart';

class AppbarWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.green[800],
      height: 150.0,
      child: Padding(
        // padding: const EdgeInsets.symmetric(horizontal: 17.5),
        padding: const EdgeInsets.only(left: 17.5, right: 17.5, top: 35),
        child: Column(
          children: [
            SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset('assets/images/logo.png',
                      width: 50, height: 50, fit: BoxFit.cover),
                  Text(
                    'Apotek Asy-Syifa',
                    style: fs20medium.copyWith(color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                  GestureDetector(
                    onTap: () {}, // tap cart
                    child: Image.asset('assets/images/shopping-cart-p.png',
                        width: 25, height: 25),
                  )
                ],
              ),
            ),
            SizedBox(height: 15),
            Container(
              width: MediaQuery.of(context).size.width - 35,
              height: 30,
              decoration: BoxDecoration(
                  color: Colors.white, borderRadius: BorderRadius.circular(8)),
              child: GestureDetector(
                onTap: () {}, // tap pencarian obat
                child: Row(
                  children: [
                    SizedBox(width: 12),
                    Image.asset('assets/images/magnifying.png',
                        width: 17.5, height: 17.5, fit: BoxFit.cover),
                    SizedBox(width: 7.5),
                    Text('Cari di Apotek Asy-Syifa', style: fs12regulercoklat)
                  ],
                ),
              ),
            ),
            SizedBox(height: 5)
          ],
        ),
      ),
    );
  }
}
