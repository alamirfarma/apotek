import 'package:apotek/theme.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'widgets/detail_produk_item_widget.dart';
import 'widgets/single_line_widget.dart';

class DetailProduk extends StatelessWidget {
  final List produkData;
  final int index;

  DetailProduk({this.produkData, this.index});

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    String imageURL = produkData[index]['gambar'];
    String namaObat = produkData[index]['nama'];
    int harga = int.parse(produkData[index]['harga_jual']);
    String satuan = produkData[index]['satuan'];
    String indikasi = produkData[index]['indikasi'];
    String dosis = produkData[index]['dosis'];
    String eso = produkData[index]['efek_samping'];
    String perhatian = produkData[index]['perhatian_khusus'];
    String nie = produkData[index]['nie'];
    String produsen = produkData[index]['produsen'];

    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Produk'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.network(
                "https://asy-syifa.web.id/apotekmobile/produk/$imageURL",
                width: width - 30,
                height: width - 30,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 14),
              Text(namaObat,
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              SizedBox(height: 8),
              Text(
                NumberFormat.currency(
                            locale: 'id', decimalDigits: 0, symbol: 'Rp ')
                        .format(harga) +
                    '/$satuan',
                style: fs12bold.copyWith(color: Colors.red),
              ),
              SizedBox(height: 15),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(title: 'Indikasi', desc: indikasi),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(title: 'Dosis', desc: dosis),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(title: 'Efek Samping', desc: eso),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(
                  title: 'Perhatian Khusus', desc: perhatian),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(title: 'Nomor Izin Edar', desc: nie),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 10),
              DetailProdukItemWidget(title: 'Diproduksi Oleh', desc: produsen),
              SizedBox(height: 10),
              SingleLineWidget(),
              SizedBox(height: 25),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Container(
        width: width,
        height: 45,
        child: Row(children: [
          GestureDetector(
            onTap: () {
              print('Masuk Keranjang');
            },
            child: Container(
              alignment: Alignment.center,
              width: width / 2,
              decoration: BoxDecoration(
                border: Border.all(
                  width: 4,
                  color: Colors.green.shade800,
                ),
                color: warnaHijauKetiga,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(35),
                ),
              ),
              child: Text(
                'Masuk Keranjang',
                style: TextStyle(
                  color: Colors.green.shade800,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: () {
              print('Beli Sekarang');
            },
            child: Container(
              alignment: Alignment.center,
              width: width / 2,
              decoration: BoxDecoration(
                color: Colors.green.shade800,
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(35),
                ),
              ),
              child: Text(
                'Beli Sekarang',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
