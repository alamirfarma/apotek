import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'home/home_page.dart';
import 'kontak/kontak_page.dart';
import 'layanan/layanan_page.dart';
import 'upload_resep/upload_resep_page.dart';

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  final List<Widget> _navigatorPage = [
    HomePage(),
    LayananPage(),
    UploadResepPage(),
    KontakPage()
  ];
  int _page = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _navigatorPage[_page],
      bottomNavigationBar: CurvedNavigationBar(
        index: _page,
        height: 50.0,
        items: <Widget>[
          Icon(Icons.home, size: 25, color: Colors.white),
          Icon(Icons.headset_mic_rounded, size: 25, color: Colors.white),
          Icon(Icons.upload_file, size: 25, color: Colors.white),
          Icon(Icons.question_answer_rounded, size: 25, color: Colors.white),
        ],
        color: Colors.green[800],
        buttonBackgroundColor: Colors.green[800],
        backgroundColor: Colors.grey[50],
        animationCurve: Curves.easeInOut,
        animationDuration: Duration(milliseconds: 300),
        onTap: (index) {
          setState(() {
            _page = index;
          });
        },
      ),
    );
  }
}
