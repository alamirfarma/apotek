import 'dart:convert';
import 'package:http/http.dart' as http;

class ProdukModel {
  final String id;
  final String nama;
  final String indikasi;
  final String dosis;
  final String efekSamping;
  final String perhatianKhusus;
  final String nie;
  final String produsen;
  final String hargaJual;
  final String idSatuan;
  final String idGolongan;
  final String idKategori;
  final String gambar;

  ProdukModel({
    this.id,
    this.nama,
    this.dosis,
    this.efekSamping,
    this.gambar,
    this.hargaJual,
    this.idGolongan,
    this.idKategori,
    this.idSatuan,
    this.indikasi,
    this.nie,
    this.perhatianKhusus,
    this.produsen,
  });

  factory ProdukModel.fromJson(Map<String, dynamic> jsonData) {
    return ProdukModel(
      id: jsonData['id'],
      nama: jsonData['nama'],
      dosis: jsonData['dosis'],
      efekSamping: jsonData['efekSamping'],
      gambar: "http://192.168.43.117/apotekmobile/produk/" + jsonData['gambar'],
      hargaJual: jsonData['hargaJual'],
      idGolongan: jsonData['idGolongan'],
      idKategori: jsonData['idKategori'],
      idSatuan: jsonData['idSatuan'],
      indikasi: jsonData['indikasi'],
      nie: jsonData['nie'],
      perhatianKhusus: jsonData['perhatianKhusus'],
      produsen: jsonData['produsen'],
    );
  }

  Future<List<ProdukModel>> downloadJSON() async {
    final jsonEndpoint =
        "http://192.168.43.117/apotekmobile/models/obat/getObat.php";

    final response = await http.get(jsonEndpoint);

    if (response.statusCode == 200) {
      print('response status OK');
      List produk = json.decode(response.body);
      return produk.map((produk) => new ProdukModel.fromJson(produk)).toList();
    } else
      throw Exception('Gagal mengambil data json');
  }
}
