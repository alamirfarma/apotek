import 'package:flutter/material.dart';

import '../../theme.dart';

class TextBoxCustomWidget extends StatelessWidget {
  final String placeholder;
  final int maxLines;

  TextBoxCustomWidget({this.placeholder, this.maxLines});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 24,
      height:
          (maxLines > 1) ? maxLines.toDouble() * 27 : maxLines.toDouble() * 40,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(width: 2, color: Colors.green[800]),
        color: warnaHijauKetiga,
      ),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: TextFormField(
          maxLines: maxLines,
          style: TextStyle(color: Colors.green[800], fontFamily: 'poppins'),
          cursorColor: Colors.green[800],
          decoration: InputDecoration(
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            errorBorder: InputBorder.none,
            contentPadding: EdgeInsets.only(left: 5, right: 5, bottom: 10),
            hintText: placeholder,
            hintStyle:
                TextStyle(color: Colors.green[800], fontFamily: 'poppins'),
          ),
        ),
      ),
    );
  }
}
