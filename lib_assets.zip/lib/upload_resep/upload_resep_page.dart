import 'dart:io';
import 'dart:ui';

import 'package:dashed_container/dashed_container.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../theme.dart';
import 'widgets/text_box_custom_widget.dart';

class UploadResepPage extends StatefulWidget {
  @override
  _UploadResepPageState createState() => _UploadResepPageState();
}

class _UploadResepPageState extends State<UploadResepPage> {
  File _image;
  final picker = ImagePicker();

  Future getImage() async {
    final pickedFile = await picker.getImage(
      source: ImageSource.camera,
    );

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Upload Resep'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 12),
              TextBoxCustomWidget(
                placeholder: 'Masukkan nama Anda',
                maxLines: 1,
              ),
              SizedBox(height: 15),
              TextBoxCustomWidget(
                placeholder: 'Masukkan nomor HP Anda',
                maxLines: 1,
              ),
              SizedBox(height: 15),
              TextBoxCustomWidget(
                placeholder: 'Masukkan alamat lengkap pengiriman obat',
                maxLines: 4,
              ),
              SizedBox(height: 15),
              Container(
                child: DashedContainer(
                  child: (_image == null)
                      ? Container(
                          width: MediaQuery.of(context).size.width - 26,
                          decoration: BoxDecoration(
                            color: warnaHijauKetiga,
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  'Upload foto resep\nyang ditulis oleh Dokter Anda.\nPosisikan resep agar berada di bagian tengah kamera.\nTim Farmasi kami akan\nmengecek keabsahan resep\nyang Anda upload.\nSelanjutnya kami akan menghubungi Anda untuk konfirmasi ketersediaan obat,\ntransaksi pembayaran, dan pengiriman.',
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w300,
                                    color: Colors.green[800],
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                              SizedBox(height: 10),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: OutlinedButton(
                                  onPressed: () {
                                    getImage();
                                  },
                                  style: OutlinedButton.styleFrom(
                                    side: BorderSide(
                                        width: 2, color: Colors.green.shade800),
                                  ),
                                  child: Text(
                                    'Foto Resep',
                                    style: TextStyle(
                                      color: Colors.green.shade800,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 10),
                            ],
                          ),
                        )
                      : Image.file(
                          _image,
                          width: MediaQuery.of(context).size.width - 20,
                          height: MediaQuery.of(context).size.width - 20,
                          fit: BoxFit.cover,
                        ),
                  dashColor: Colors.green[800],
                  borderRadius: 10.0,
                  dashedLength: 10.0,
                  blankLength: 6.0,
                  strokeWidth: 4.0,
                ),
              ),
              SizedBox(height: 15),
              Container(
                width: MediaQuery.of(context).size.width / 1.8,
                height: 40,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    primary: Colors.green.shade800,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                  child: Text(
                    'Proses Resep',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
