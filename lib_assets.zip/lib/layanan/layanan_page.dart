import 'package:flutter/material.dart';
import 'widgets/layanan_widget.dart';

class LayananPage extends StatefulWidget {
  @override
  _LayananPageState createState() => _LayananPageState();
}

class _LayananPageState extends State<LayananPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Layanan'),
        centerTitle: true,
      ),
      body: ListView(
        shrinkWrap: true,
        children: [
          SizedBox(height: 20),
          LayananWidget(
              imageURL: 'assets/images/rapid.png',
              title: 'Rapid Test Antigen', 
              descLayanan:
                  'Lakukan pemeriksaan rapid test antigen untuk sekedar check-up, untuk perjalanan, maupun untuk kepentingan lain'),
          SizedBox(height: 15),
          LayananWidget(
              imageURL: 'assets/images/swab.png',
              title: 'Swab PCR',
              descLayanan:
                  'Lakukan pemeriksaan Swab PCR untuk sekedar check-up, untuk perjalanan, maupun untuk kepentingan lain'),
          SizedBox(height: 15),
          LayananWidget(
              imageURL: 'assets/images/upload-resep.png',
              title: 'Upload Resep',
              descLayanan:
                  'Upload foto resep Anda, obat akan dikirim ke tempat Anda'),
          SizedBox(height: 15),
          LayananWidget(
              imageURL: 'assets/images/konsultasi.png',
              title: 'Konsultasi Dokter',
              descLayanan:
                  'Konsultasikan masalah kesehatan Anda dengan Dokter kami'),
          SizedBox(height: 15),
          LayananWidget(
              imageURL: 'assets/images/pengantaran.png',
              title: 'Pengantaran Obat',
              descLayanan:
                  'Silahkan belanja dengan metode pengiriman “Diantarkan”. Obat akan diantarkan ke tempat Anda'),
        ],
      ),
    );
  }
}
