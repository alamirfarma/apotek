import 'package:flutter/material.dart';

import '../../theme.dart';

class LayananWidget extends StatelessWidget {
  final String imageURL;
  final String title;
  final String descLayanan;

  LayananWidget({this.descLayanan, this.imageURL, this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Row(
        children: [
          Image.asset(this.imageURL,
              width: (MediaQuery.of(context).size.width * 1 / 4) - 20,
              height: (MediaQuery.of(context).size.width * 1 / 4) - 20,
              fit: BoxFit.cover),
          SizedBox(width: 8),
          Container(
            width: MediaQuery.of(context).size.width * 3 / 4,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  this.title,
                  style: fs14semibold, 
                  textAlign: TextAlign.right,
                ),
                SizedBox(height: 3),
                Text(
                  this.descLayanan,
                  style: fs12light.copyWith(color: Color(0xff646363)),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}
