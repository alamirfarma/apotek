import 'package:apotek/functions/konversi_waktu.dart';
import 'package:apotek/theme.dart';
import 'package:flutter/material.dart';

import 'widgets/kontak_item_widget.dart';

class KontakPage extends StatelessWidget {
  final String ucapan = konversiWaktuUcapan();

  @override
  Widget build(BuildContext context) {
    print(konversiWaktuUcapan());

    return Scaffold(
      appBar: AppBar(
        title: Text('Kontak'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 35),
                Image.asset(
                  'assets/images/logo.png',
                  width: 100,
                  height: 100,
                  fit: BoxFit.cover,
                ),
                SizedBox(height: 25),
                Text(
                  'Apotek Asy-Syifa',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                ),
                SizedBox(height: 21),
                Container(
                  width: MediaQuery.of(context).size.width - 30,
                  decoration: BoxDecoration(
                    color: warnaHijauKetiga,
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: Padding(
                    padding: EdgeInsets.all(15),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        KontakItemWidget(
                          imageURL: 'assets/images/alamat.png',
                          kontakDesc:
                              'Jl. Daeng Macirrinae, Desa Tobadak, Mamuju Tengah',
                          launchURL: 'https://goo.gl/maps/4oYXGgB3sbYYYxuD6',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/telp.png',
                          kontakDesc: '085236295323',
                          launchURL: 'tel://085236295323',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/whatsapp.png',
                          kontakDesc: '085236295323',
                          launchURL:
                              'https://wa.me/+6285236295323?text=$ucapan,%0ADengan apotek Asy-Syifa?%0A%0A%0A%23Asy-Syifa Mobile App',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/email.png',
                          kontakDesc: 'asysyifamateng@gmail.com',
                          launchURL: 'mailto:asysyifamateng@gmail.com',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/www.png',
                          kontakDesc: 'asy-syifa.web.id',
                          launchURL: 'https://asy-syifa.web.id',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/instagram.png',
                          kontakDesc: '@apotek_asy_syifa',
                        ),
                        SizedBox(height: 15),
                        KontakItemWidget(
                          imageURL: 'assets/images/youtube.png',
                          kontakDesc: 'Apotek Asy-Syifa',
                          launchURL:
                              'https://www.youtube.com/channel/UC8YMNjGVvl9osnhVLK9FXfA/featured',
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
