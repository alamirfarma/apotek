import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class KontakItemWidget extends StatelessWidget {
  final String imageURL;
  final String kontakDesc;
  final String launchURL;

  KontakItemWidget({this.imageURL, this.kontakDesc, this.launchURL});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            imageURL,
            width: 30,
            height: 30,
            fit: BoxFit.contain,
          ),
          SizedBox(width: 15),
          Flexible(
            child: Text(
              kontakDesc,
              style: TextStyle(
                color: Colors.green.shade800,
                fontSize: 14,
                fontWeight: FontWeight.w300,
              ),
            ),
          )
        ],
      ),
      onTap: () {
        launch(launchURL);
      },
    );
  }
}
