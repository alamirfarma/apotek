String konversiWaktuUcapan() {
  final currentTime = DateTime.now();

  if (currentTime.isAfter(DateTime(DateTime.now().year, DateTime.now().month,
          DateTime.now().day, 00, 00)) &&
      currentTime.isBefore(DateTime(DateTime.now().year, DateTime.now().month,
          DateTime.now().day, 12, 00))) {
    return "Selamat Pagi";
  } else if (currentTime.isAfter(DateTime(DateTime.now().year,
          DateTime.now().month, DateTime.now().day, 11, 59)) &&
      currentTime.isBefore(DateTime(DateTime.now().year, DateTime.now().month,
          DateTime.now().day, 15, 00))) {
    return "Selamat Siang";
  } else if (currentTime.isAfter(DateTime(DateTime.now().year,
          DateTime.now().month, DateTime.now().day, 14, 59)) &&
      currentTime.isBefore(DateTime(DateTime.now().year, DateTime.now().month,
          DateTime.now().day, 18, 00))) {
    return "Selamat Sore";
  } else if (currentTime.isAfter(DateTime(DateTime.now().year,
          DateTime.now().month, DateTime.now().day, 17, 59)) &&
      currentTime.isBefore(DateTime(DateTime.now().year, DateTime.now().month,
          DateTime.now().day, 24, 00))) {
    return "Selamat Malam";
  } else {
    return "Selamat Malam";
  }
}
